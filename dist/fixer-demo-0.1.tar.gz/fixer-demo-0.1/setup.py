from setuptools import setup

setup(name='fixer-demo',
      version='0.1',
      description='fixer service demo package',
      url='#',
      author='pouria',
      author_email='pouria.72@yahoo.com',
      license='MIT',
      packages=['fixer'],
      zip_safe=False)